package app.sonicrumble.modmanager

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * Copia os arquivos dos mods para a pasta do jogo (via SAF), guardando antes
 * uma cópia dos originais em filesDir/backup para poder restaurar.
 */
class GameInstaller(private val ctx: Context, private val gameRoot: DocumentFile) {
    private val backupRoot = File(ctx.filesDir, "backup")
    private val backupDir = File(backupRoot, "files")
    private val addedFile = File(backupRoot, "added.txt")
    private val cr = ctx.contentResolver

    fun hasState(): Boolean = backupRoot.exists() && (backupRoot.list()?.isNotEmpty() == true)

    fun apply(mods: List<Mod>, store: ModStore, log: (String) -> Unit) {
        restore(log) // começa sempre do jogo original
        backupDir.mkdirs()
        val added = HashSet<String>()
        val backedUp = HashSet<String>()
        for (mod in mods) {
            log("Aplicando ${mod.title}...")
            for ((rel, src) in store.filesOf(mod)) {
                var target = find(rel)
                if (rel !in added && rel !in backedUp) {
                    if (target != null) {
                        val b = File(backupDir, rel)
                        b.parentFile?.mkdirs()
                        cr.openInputStream(target.uri)!!.use { i -> b.outputStream().use { i.copyTo(it) } }
                        backedUp.add(rel)
                    } else {
                        added.add(rel)
                        addedFile.appendText(rel + "\n")
                    }
                }
                if (target == null) target = create(rel)
                cr.openOutputStream(target.uri, "wt")!!.use { o -> src.inputStream().use { it.copyTo(o) } }
            }
        }
    }

    fun restore(log: (String) -> Unit) {
        if (backupDir.exists()) {
            backupDir.walkTopDown().filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(backupDir).path.replace('\\', '/')
                val t = find(rel) ?: create(rel)
                cr.openOutputStream(t.uri, "wt")!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                log("Restaurado: $rel")
            }
        }
        if (addedFile.exists()) {
            addedFile.readLines().filter { it.isNotBlank() }.forEach { rel ->
                find(rel)?.delete()
                log("Removido: $rel")
            }
        }
        backupRoot.deleteRecursively()
    }

    private fun find(rel: String): DocumentFile? {
        var cur: DocumentFile? = gameRoot
        for (seg in rel.split('/').filter { it.isNotEmpty() }) {
            cur = cur?.findFile(seg)
            if (cur == null) return null
        }
        return cur
    }

    private fun create(rel: String): DocumentFile {
        val segs = rel.split('/').filter { it.isNotEmpty() }
        var cur: DocumentFile = gameRoot
        for (seg in segs.dropLast(1)) {
            cur = cur.findFile(seg) ?: cur.createDirectory(seg)
                ?: throw IllegalStateException("Não foi possível criar a pasta $seg")
        }
        val name = segs.last()
        val f = cur.createFile("application/octet-stream", name)
            ?: throw IllegalStateException("Não foi possível criar $rel")
        if (f.name != name) f.renameTo(name)
        return f
    }
}
