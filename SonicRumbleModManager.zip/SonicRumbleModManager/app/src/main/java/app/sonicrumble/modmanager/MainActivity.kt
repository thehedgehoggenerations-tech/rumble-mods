package app.sonicrumble.modmanager

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {

    companion object {
        const val PKG = "com.sega.sonicrumble"
        const val REQ_FOLDER = 1
        const val REQ_ZIP = 2
        const val REQ_QUICK = 3
    }

    private lateinit var store: ModStore
    private lateinit var prefs: SharedPreferences
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var mods: MutableList<Mod> = mutableListOf()
    private var folderLine = ""
    @Volatile private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ModStore(this)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        buildUi()
        refresh()
        checkFolder()
    }

    // ---------- UI ----------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply { text = "Sonic Rumble Mod Manager"; textSize = 20f })
        status = TextView(this).apply { setPadding(0, 16, 0, 16) }
        root.addView(status)
        root.addView(button("Escolher mod e jogar") { quickPlay() }.apply { textSize = 18f })
        root.addView(row(
            button("Pasta do jogo") { pickFolder() },
            button("Importar .zip") { pickZip() }
        ))
        root.addView(row(
            button("Aplicar") { applyMods() },
            button("Restaurar") { restoreAll() },
            button("Abrir jogo") { launchGame() }
        ))
        root.addView(TextView(this).apply {
            text = "Marque os mods. Mods mais abaixo sobrescrevem os de cima. Segure um item para mais opções."
            textSize = 12f
            setPadding(0, 16, 0, 8)
        })
        list = ListView(this).apply { choiceMode = ListView.CHOICE_MODE_MULTIPLE }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        list.setOnItemClickListener { _, _, pos, _ ->
            store.setEnabled(mods[pos].id, list.isItemChecked(pos))
        }
        list.setOnItemLongClickListener { _, _, pos, _ -> showModMenu(pos); true }
        setContentView(root)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun refresh() {
        mods = store.list().toMutableList()
        val labels = mods.map { m ->
            buildString {
                append(m.title)
                if (m.version.isNotBlank()) append("  v${m.version}")
                append("\n${m.author}")
            }
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, labels)
        mods.forEachIndexed { i, m -> list.setItemChecked(i, store.isEnabled(m.id)) }
    }

    private fun updateStatus(msg: String? = null) {
        status.text = if (msg == null) folderLine else "$folderLine\n$msg"
    }

    private fun checkFolder() {
        folderLine = when {
            prefs.getString("tree", null) == null -> "Pasta do jogo: não escolhida"
            gameRoot() != null -> "Pasta do jogo: OK ($PKG)"
            else -> "Pasta do jogo: $PKG não encontrada na pasta escolhida"
        }
        updateStatus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- pastas / arquivos ----------

    private fun gameRoot(): DocumentFile? {
        val s = prefs.getString("tree", null) ?: return null
        val t = try { DocumentFile.fromTreeUri(this, Uri.parse(s)) } catch (e: Exception) { null } ?: return null
        if (t.name == PKG) return t
        return t.findFile(PKG) ?: t.findFile("data")?.findFile(PKG)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.putExtra(
            DocumentsContract.EXTRA_INITIAL_URI,
            DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Android/data")
        )
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try {
            startActivityForResult(i, REQ_FOLDER)
        } catch (e: Exception) {
            toast("Não foi possível abrir o seletor de pastas: ${e.message}")
        }
    }

    private fun pickZip(code: Int = REQ_ZIP) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, code)
    }

    /** Fluxo rápido: escolhe o .zip, aplica só esse mod, abre o jogo e fecha o app. */
    private fun quickPlay() {
        if (gameRoot() == null) {
            toast("Primeiro escolha a pasta do jogo (Android > data)")
            pickFolder()
            return
        }
        pickZip(REQ_QUICK)
    }

    private fun quickApply(uri: Uri) {
        val root = gameRoot() ?: return toast("Escolha primeiro a pasta do jogo")
        val name = displayName(uri).removeSuffix(".zip")
        work { log ->
            log("Importando $name...")
            val id = contentResolver.openInputStream(uri)!!.use { store.importZip(it, name) }
            store.list().forEach { store.setEnabled(it.id, it.id == id) }
            val mod = store.list().first { it.id == id }
            log("Aplicando $name...")
            GameInstaller(this, root).apply(listOf(mod), store, log)
            runOnUiThread {
                refresh()
                val launch = packageManager.getLaunchIntentForPackage(PKG)
                if (launch != null) {
                    startActivity(launch)
                    finish()
                } else {
                    updateStatus("Mod aplicado, mas o jogo não foi encontrado")
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_FOLDER -> {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (e: Exception) { /* segue mesmo assim */ }
                prefs.edit().putString("tree", uri.toString()).apply()
                checkFolder()
            }
            REQ_ZIP -> importZip(uri)
            REQ_QUICK -> quickApply(uri)
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i)
            }
        }
        return "mod.zip"
    }

    // ---------- ações ----------

    private fun work(block: ((String) -> Unit) -> Unit) {
        if (busy) { toast("Aguarde a operação atual terminar"); return }
        busy = true
        Thread {
            try {
                block { m -> runOnUiThread { updateStatus(m) } }
            } catch (e: Throwable) {
                runOnUiThread { updateStatus("Erro: ${e.message ?: e.javaClass.simpleName}") }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun importZip(uri: Uri) {
        val name = displayName(uri).removeSuffix(".zip")
        work { log ->
            contentResolver.openInputStream(uri)!!.use { store.importZip(it, name) }
            runOnUiThread { refresh() }
            log("Mod importado: $name")
        }
    }

    private fun applyMods() {
        val root = gameRoot() ?: return toast("Escolha primeiro a pasta do jogo")
        val active = mods.filter { store.isEnabled(it.id) }
        if (active.isEmpty()) return toast("Nenhum mod marcado")
        work { log ->
            GameInstaller(this, root).apply(active, store, log)
            log("Concluído: ${active.size} mod(s) aplicado(s)")
        }
    }

    private fun restoreAll() {
        val root = gameRoot() ?: return toast("Escolha primeiro a pasta do jogo")
        work { log ->
            val g = GameInstaller(this, root)
            if (!g.hasState()) {
                log("Nada para restaurar")
            } else {
                g.restore(log)
                log("Arquivos originais restaurados")
            }
        }
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(PKG)
        if (i == null) toast("Jogo não encontrado") else startActivity(i)
    }

    private fun showModMenu(pos: Int) {
        val m = mods[pos]
        AlertDialog.Builder(this)
            .setTitle(m.title)
            .setItems(arrayOf("Detalhes", "Subir", "Descer", "Excluir")) { _, which ->
                when (which) {
                    0 -> AlertDialog.Builder(this)
                        .setTitle(m.title)
                        .setMessage("Autor: ${m.author}\nVersão: ${m.version}\n\n${m.description}\n\nArquivos: ${store.filesOf(m).size}")
                        .setPositiveButton("OK", null)
                        .show()
                    1 -> move(pos, -1)
                    2 -> move(pos, 1)
                    3 -> { store.delete(m); refresh() }
                }
            }
            .show()
    }

    private fun move(pos: Int, delta: Int) {
        val n = pos + delta
        if (n !in mods.indices) return
        java.util.Collections.swap(mods, pos, n)
        store.saveOrder(mods)
        refresh()
    }
}
