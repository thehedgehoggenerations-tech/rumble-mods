package app.sonicrumble.modmanager

import android.content.Context
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

data class Mod(
    val id: String,
    val dir: File,
    val title: String,
    val author: String,
    val version: String,
    val description: String
)

/** Guarda os mods importados em filesDir/mods/<id>/ (mod.ini + arquivos). */
class ModStore(private val ctx: Context) {
    private val modsDir = File(ctx.filesDir, "mods").also { it.mkdirs() }
    private val prefs = ctx.getSharedPreferences("mods", Context.MODE_PRIVATE)

    fun list(): List<Mod> {
        val all = (modsDir.listFiles() ?: emptyArray())
            .filter { it.isDirectory }
            .map { readMod(it) }
            .associateBy { it.id }
        val order = (prefs.getString("order", "") ?: "").split("\n").filter { it.isNotBlank() }
        val result = mutableListOf<Mod>()
        order.forEach { id -> all[id]?.let { result.add(it) } }
        all.values.filter { m -> result.none { it.id == m.id } }
            .sortedBy { it.id }
            .forEach { result.add(it) }
        return result
    }

    fun saveOrder(mods: List<Mod>) {
        prefs.edit().putString("order", mods.joinToString("\n") { it.id }).apply()
    }

    fun isEnabled(id: String): Boolean =
        (prefs.getStringSet("enabled", emptySet()) ?: emptySet()).contains(id)

    fun setEnabled(id: String, on: Boolean) {
        val s = HashSet(prefs.getStringSet("enabled", emptySet()) ?: emptySet())
        if (on) s.add(id) else s.remove(id)
        prefs.edit().putStringSet("enabled", s).apply()
    }

    fun delete(mod: Mod) {
        mod.dir.deleteRecursively()
        setEnabled(mod.id, false)
    }

    /** Arquivos do mod (caminho relativo -> arquivo), ignorando o mod.ini da raiz. */
    fun filesOf(mod: Mod): List<Pair<String, File>> =
        mod.dir.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(mod.dir).path.replace('\\', '/') to it }
            .filter { it.first.lowercase() != "mod.ini" }
            .toList()

    private fun readMod(dir: File): Mod {
        val kv = HashMap<String, String>()
        val ini = File(dir, "mod.ini")
        if (ini.exists()) {
            ini.forEachLine { raw ->
                val line = raw.trim()
                val i = line.indexOf('=')
                if (i > 0 && !line.startsWith("[") && !line.startsWith(";") && !line.startsWith("#")) {
                    kv[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
                }
            }
        }
        return Mod(
            id = dir.name,
            dir = dir,
            title = kv["title"] ?: kv["name"] ?: dir.name,
            author = kv["author"] ?: "autor desconhecido",
            version = kv["version"] ?: "",
            description = kv["description"] ?: ""
        )
    }

    /** Importa um .zip. O mod.ini pode estar na raiz do zip ou dentro de uma única pasta. */
    fun importZip(input: InputStream, nameHint: String): String {
        val tmp = File(ctx.cacheDir, "import_${System.nanoTime()}").also { it.mkdirs() }
        try {
            ZipInputStream(input).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val name = e.name.replace('\\', '/')
                    val out = File(tmp, name)
                    if (!out.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) {
                        throw SecurityException("Caminho inválido no zip: $name")
                    }
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            val root = when {
                File(tmp, "mod.ini").exists() -> tmp
                else -> tmp.listFiles()?.firstOrNull { it.isDirectory && File(it, "mod.ini").exists() }
            } ?: throw IllegalArgumentException("mod.ini não encontrado no zip")

            val base = (if (root == tmp) nameHint else root.name)
                .replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "mod" }
            var id = base
            var n = 2
            while (File(modsDir, id).exists()) { id = "$base-$n"; n++ }
            root.copyRecursively(File(modsDir, id), overwrite = false)
            return id
        } finally {
            tmp.deleteRecursively()
        }
    }
}
