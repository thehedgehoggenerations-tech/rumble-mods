# Sonic Rumble Mod Manager (Android)

Gerenciador de mods para o Sonic Rumble (pacote `com.sega.sonicrumble`), no mesmo
estilo do RumbleModManager de PC: substitui arquivos do jogo e guarda backup dos originais.

## Como compilar
Sem PC: veja a pasta .github/workflows (o GitHub compila o APK para você).

Com PC:
1. Instale o Android Studio e abra a pasta `SonicRumbleModManager`.
2. Aguarde o "Gradle Sync" (precisa de internet na primeira vez).
3. Ligue o celular com a depuração USB ativa e clique em Run, ou use
   Build > Build APK(s) e instale o APK gerado.

## Formato do mod (igual ao PC)
```
MeuMod/
  mod.ini        (Title=..., Author=..., Version=..., Description=...)
  <arquivos espelhando a pasta do jogo>
```
Os caminhos dentro do mod são relativos a `Android/data/com.sega.sonicrumble/`.
O mod pode ser importado em .zip (com mod.ini na raiz ou dentro de uma pasta).

## Uso rápido
Abra o app, toque em "Escolher mod e jogar", selecione o .zip do mod. O app aplica o mod,
abre o Sonic Rumble e se fecha. (Na primeira vez ele pede a pasta Android > data.)

## Uso completo
1. "Pasta do jogo": no seletor, vá até Android > data e toque em "Usar esta pasta".
2. "Importar .zip": adicione os mods.
3. Marque os mods, ajuste a ordem (segure o item) e toque em "Aplicar".
4. "Restaurar" devolve os arquivos originais.

## Avisos
- Se o jogo for atualizado, use "Restaurar" ANTES de atualizar; o backup é da versão antiga.
- Modificar arquivos de um jogo online pode gerar banimento. Use só mods visuais/locais.
- No Android 13+ o acesso a Android/data por esse método é bloqueado (precisaria de Shizuku).
